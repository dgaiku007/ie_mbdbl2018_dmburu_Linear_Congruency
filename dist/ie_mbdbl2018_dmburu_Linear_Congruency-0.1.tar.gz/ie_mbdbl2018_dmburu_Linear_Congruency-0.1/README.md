# ie_mbdbl2018_dmburu-Linear_Congruency
This is a simple minimal set of codes to create a Python Package
What this Function does is - return the Linear Congruency & the random number 1 or 0 generated through it!!

TEST PUSHING...
...
"# ie_mbdbl2018_dmburu-Linear_Congruency" 
